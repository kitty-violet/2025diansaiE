#include "ti_msp_dl_config.h"

void PWM_2SetCompare3(uint16_t Compare);
void Servo_SetAngle(float Angle);
// void Addangle();
// void Reduceangle();