#include "Servo.h"
void PWM_2SetCompare3(uint16_t Compare)
{ 
    DL_TimerA_setCaptureCompareValue(PWM_Servo_INST,Compare,DL_TIMER_CC_0_INDEX);
}
void Servo_SetAngle(float Angle)
{
	PWM_2SetCompare3(Angle / 180 * 2000 + 500);
}
// float Addangle(float Angle)
// {
//     Angle++;
//     Servo_SetAngle(Angle);
//     return Angle;

// }
// void Reduceangle()
// {
//     int i=180;
//     while(i>=0)
//     {    Servo_SetAngle(i);
//          delay_cycles( 800000);
//          i--;
//     }
// }

