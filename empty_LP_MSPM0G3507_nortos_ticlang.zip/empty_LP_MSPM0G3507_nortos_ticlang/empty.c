/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ti_msp_dl_config.h"
#include "motor.h"
#include "Servo.h"
#include"Car.h"
float x_angle=90;
float y_angle=90;
void UART_OPENMV_INST_IRQHandler(void);
int main(void)
{
     SYSCFG_DL_init();
     NVIC_ClearPendingIRQ(UART_OPENMV_INST_INT_IRQN);
     NVIC_EnableIRQ(UART_OPENMV_INST_INT_IRQN);
    Servo_SetAngle(90);
     while (1) 
     {
     //goahead();
     UART_OPENMV_INST_IRQHandler(); 
    //  delay_cycles( 160000000);
    //  stop();
    //  delay_cycles( 160000000);
    //  goback();
    //  delay_cycles( 160000000);
    //  selfright();
    //  delay_cycles( 160000000);
    //  selfleft();
    //  delay_cycles( 160000000);
    }
}


void UART_OPENMV_INST_IRQHandler(void)
{
    uint8_t gData;
    switch (DL_UART_Main_getPendingInterrupt(UART_OPENMV_INST)) {
        case DL_UART_MAIN_IIDX_RX:
            gData = DL_UART_Main_receiveData(UART_OPENMV_INST);
            // if(gData == 'r')
            //     selfright();
            // else if(gData == 'l')
            //     selfleft();
            // else if(gData == 'f')
            //     goahead();
            // else if(gData == 'n')
            //     {goback();
            //     delay_cycles( 64000000);}
            if(gData=='L')
            {
                x_angle--;
                Servo_SetAngle(x_angle);
            }
            else if(gData=='R')
            {
                x_angle++;
                Servo_SetAngle(x_angle);
            }
            else if(gData=='D')
            {
                y_angle--;
                Servo_SetAngle(y_angle);
            }
            else if(gData=='U')
            {
                y_angle++;
                Servo_SetAngle(y_angle);
            }
            else if(gData=='O')
            {
            DL_GPIO_setPins(GPIO_LED_PORT,GPIO_LED_PIN_4_PIN);
            }                                    
            else stop();
            break;
        default:
            break;
    }
}


// int main(void)
// {
//      SYSCFG_DL_init();
//     // Servo_SetAngle(810);
//         // Servo_SetAngle(0);
//         // delay_cycles( 160000000);
//         // Addangle();
//         // delay_cycles( 160000000);
//         // Reduceangle();

//         // Servo_SetAngle(180);
//         // goahead();
//         // delay_cycles( 320000000);
//         // stop();
//         // delay_cycles( 320000000);
//      while (1) 
//      {
//         // if(DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_0_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_1_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_2_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_3_PIN)==0)
//         // {
//         //     goahead();
//         // }
//         // else if(DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_0_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_1_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_2_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_3_PIN)>0)
//         //     {
//         //     do{stop();
//         //     }while(1);            
//         //     }
//         // else if(DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_0_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_1_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_2_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_3_PIN)>0)
//         //     {
//         //         stop();
//         //     do{  
//         //     selfright();
//         //     }while(DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_0_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_1_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_2_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_3_PIN)>0);
            

//         // }else if(DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_0_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_1_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_2_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_3_PIN)==0){
//         //         stop();
//         //         do{
//         //     selfright();
//         //         }while(DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_0_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_1_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_2_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_3_PIN)==0);
                
                
//         // }else if(DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_0_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_1_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_2_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_3_PIN)>0){
//         //         stop();
//         //         do{
//         //         selfright();
//         //         }while(DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_0_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_1_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_2_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_3_PIN)>0);
                
                
//         //     }
//         //     else if(DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_0_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_1_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_2_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_3_PIN)==0){
//         //         stop();
//         //         do{
//         //         selfleft();
//         //         }while(DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_0_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_1_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_2_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_3_PIN)==0);
                
                
//         //     }else if(DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_0_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_1_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_2_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_3_PIN)==0){
//         //         stop();
//         //         do{
//         //         selfleft();
//         //         }while(DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_0_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_1_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_2_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_3_PIN)==0);
                
//         //     }else if(DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_0_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_1_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_2_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_3_PIN)==0){
//         //     stop();
//         //         do{
//         //         selfleft();
//         //         }while(DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_0_PIN)>0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_1_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_2_PIN)==0&&
//         //     DL_GPIO_readPins(GPIO_Sensor_PORT, GPIO_Sensor_PIN_3_PIN)==0);
//         //     }
//     //     delay_cycles( 32000000);
//     //     Servo_SetAngle(0);
//     //     delay_cycles( 32000000);
//      //     Set_Speed(0, 40);
//      //     Set_Speed(1, 40);
//     //  goahead();
//     //  delay_cycles( 160000000);
//     //  stop();
//     //  delay_cycles( 160000000);
//     //  goback();
//     //  delay_cycles( 160000000);
//     //  selfright();
//     //  delay_cycles( 160000000);
//     //  selfleft();
//     //  delay_cycles( 160000000);
//     }
// }



