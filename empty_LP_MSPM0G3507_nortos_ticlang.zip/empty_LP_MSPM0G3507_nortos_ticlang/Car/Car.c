#include "Car.h"
#include "motor.h"
#include "Servo.h"
void goahead(void)
{
    Servo_SetAngle(90);
    Set_Speed(0, -40);
    Set_Speed(1, -40);
}
void stop(void)
{
   Servo_SetAngle(90);
    Set_Speed(0, 0);
    Set_Speed(1, 0);
}
void goback(void)
{
    Servo_SetAngle(90);
    Set_Speed(0, 40);
    Set_Speed(1, 40);//
}
void selfright(void)
{
    Servo_SetAngle(180);
    Set_Speed(0, 40);
    Set_Speed(1, -40);//
}
void selfleft(void)
{
    Servo_SetAngle(0);
    Set_Speed(0, -40);
    Set_Speed(1, 40);
}