#include "ti_msp_dl_config.h"

void Motor_Off(void);
void Set_Speed(uint8_t side, int8_t duty);