#include "Car.h"
#include "motor.h"
#include "Servo.h"
void goahead(void)
{
    Servo_SetAngle(90);
    Set_Speed(0, -28);//-37
    Set_Speed(1, -30);//-40
}
void stop(void)
{
   Servo_SetAngle(90);
    Set_Speed(0, 0);
    Set_Speed(1, 0);
}
void goback(void)
{
    Servo_SetAngle(90);
    Set_Speed(0, 40);
    Set_Speed(1, 40);//
}
void selfright(void)
{
    Servo_SetAngle(180);
    Set_Speed(0, 20);
    Set_Speed(1, -30);//
}
void selfleft(void)
{
    Servo_SetAngle(0);
    Set_Speed(0, -30);
    Set_Speed(1, 20);
}
void turnright(void)
{
    Servo_SetAngle(180);
    Set_Speed(0, -5);//20
    Set_Speed(1, -40);
}
void turnleft(void)
{
    Servo_SetAngle(0);
    Set_Speed(0, -40);
    Set_Speed(1, -5);//20
}