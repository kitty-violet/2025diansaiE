################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Car/Car.c 

C_DEPS += \
./Car/Car.d 

OBJS += \
./Car/Car.o 

OBJS__QUOTED += \
"Car\Car.o" 

C_DEPS__QUOTED += \
"Car\Car.d" 

C_SRCS__QUOTED += \
"../Car/Car.c" 


