/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define CPUCLK_FREQ                                                     32000000



/* Defines for PWM_MOTOR */
#define PWM_MOTOR_INST                                                     TIMA1
#define PWM_MOTOR_INST_IRQHandler                               TIMA1_IRQHandler
#define PWM_MOTOR_INST_INT_IRQN                                 (TIMA1_INT_IRQn)
#define PWM_MOTOR_INST_CLK_FREQ                                         32000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_MOTOR_C0_PORT                                             GPIOA
#define GPIO_PWM_MOTOR_C0_PIN                                     DL_GPIO_PIN_28
#define GPIO_PWM_MOTOR_C0_IOMUX                                   (IOMUX_PINCM3)
#define GPIO_PWM_MOTOR_C0_IOMUX_FUNC                  IOMUX_PINCM3_PF_TIMA1_CCP0
#define GPIO_PWM_MOTOR_C0_IDX                                DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_MOTOR_C1_PORT                                             GPIOB
#define GPIO_PWM_MOTOR_C1_PIN                                      DL_GPIO_PIN_3
#define GPIO_PWM_MOTOR_C1_IOMUX                                  (IOMUX_PINCM16)
#define GPIO_PWM_MOTOR_C1_IOMUX_FUNC                 IOMUX_PINCM16_PF_TIMA1_CCP1
#define GPIO_PWM_MOTOR_C1_IDX                                DL_TIMER_CC_1_INDEX

/* Defines for PWM_Servo */
#define PWM_Servo_INST                                                     TIMA0
#define PWM_Servo_INST_IRQHandler                               TIMA0_IRQHandler
#define PWM_Servo_INST_INT_IRQN                                 (TIMA0_INT_IRQn)
#define PWM_Servo_INST_CLK_FREQ                                          1000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_Servo_C0_PORT                                             GPIOB
#define GPIO_PWM_Servo_C0_PIN                                     DL_GPIO_PIN_14
#define GPIO_PWM_Servo_C0_IOMUX                                  (IOMUX_PINCM31)
#define GPIO_PWM_Servo_C0_IOMUX_FUNC                 IOMUX_PINCM31_PF_TIMA0_CCP0
#define GPIO_PWM_Servo_C0_IDX                                DL_TIMER_CC_0_INDEX



/* Defines for UART_OPENMV */
#define UART_OPENMV_INST                                                   UART1
#define UART_OPENMV_INST_FREQUENCY                                      32000000
#define UART_OPENMV_INST_IRQHandler                             UART1_IRQHandler
#define UART_OPENMV_INST_INT_IRQN                                 UART1_INT_IRQn
#define GPIO_UART_OPENMV_RX_PORT                                           GPIOB
#define GPIO_UART_OPENMV_TX_PORT                                           GPIOB
#define GPIO_UART_OPENMV_RX_PIN                                    DL_GPIO_PIN_7
#define GPIO_UART_OPENMV_TX_PIN                                    DL_GPIO_PIN_6
#define GPIO_UART_OPENMV_IOMUX_RX                                (IOMUX_PINCM24)
#define GPIO_UART_OPENMV_IOMUX_TX                                (IOMUX_PINCM23)
#define GPIO_UART_OPENMV_IOMUX_RX_FUNC                 IOMUX_PINCM24_PF_UART1_RX
#define GPIO_UART_OPENMV_IOMUX_TX_FUNC                 IOMUX_PINCM23_PF_UART1_TX
#define UART_OPENMV_BAUD_RATE                                             (9600)
#define UART_OPENMV_IBRD_32_MHZ_9600_BAUD                                  (208)
#define UART_OPENMV_FBRD_32_MHZ_9600_BAUD                                   (21)





/* Port definition for Pin Group GPIO_LED */
#define GPIO_LED_PORT                                                    (GPIOB)

/* Defines for PIN_4: GPIOB.15 with pinCMx 32 on package pin 3 */
#define GPIO_LED_PIN_4_PIN                                      (DL_GPIO_PIN_15)
#define GPIO_LED_PIN_4_IOMUX                                     (IOMUX_PINCM32)
/* Port definition for Pin Group KEY1 */
#define KEY1_PORT                                                        (GPIOA)

/* Defines for PIN_A18: GPIOA.18 with pinCMx 40 on package pin 11 */
#define KEY1_PIN_A18_PIN                                        (DL_GPIO_PIN_18)
#define KEY1_PIN_A18_IOMUX                                       (IOMUX_PINCM40)
/* Port definition for Pin Group KEY2 */
#define KEY2_PORT                                                        (GPIOB)

/* Defines for PIN_B21: GPIOB.21 with pinCMx 49 on package pin 20 */
#define KEY2_PIN_B21_PIN                                        (DL_GPIO_PIN_21)
#define KEY2_PIN_B21_IOMUX                                       (IOMUX_PINCM49)
/* Defines for PIN_FL1: GPIOA.25 with pinCMx 55 on package pin 26 */
#define GPIO_MOTOR_PIN_FL1_PORT                                          (GPIOA)
#define GPIO_MOTOR_PIN_FL1_PIN                                  (DL_GPIO_PIN_25)
#define GPIO_MOTOR_PIN_FL1_IOMUX                                 (IOMUX_PINCM55)
/* Defines for PIN_FL2: GPIOA.12 with pinCMx 34 on package pin 5 */
#define GPIO_MOTOR_PIN_FL2_PORT                                          (GPIOA)
#define GPIO_MOTOR_PIN_FL2_PIN                                  (DL_GPIO_PIN_12)
#define GPIO_MOTOR_PIN_FL2_IOMUX                                 (IOMUX_PINCM34)
/* Defines for PIN_FR1: GPIOB.13 with pinCMx 30 on package pin 1 */
#define GPIO_MOTOR_PIN_FR1_PORT                                          (GPIOB)
#define GPIO_MOTOR_PIN_FR1_PIN                                  (DL_GPIO_PIN_13)
#define GPIO_MOTOR_PIN_FR1_IOMUX                                 (IOMUX_PINCM30)
/* Defines for PIN_FR2: GPIOB.12 with pinCMx 29 on package pin 64 */
#define GPIO_MOTOR_PIN_FR2_PORT                                          (GPIOB)
#define GPIO_MOTOR_PIN_FR2_PIN                                  (DL_GPIO_PIN_12)
#define GPIO_MOTOR_PIN_FR2_IOMUX                                 (IOMUX_PINCM29)
/* Port definition for Pin Group GPIO_Sensor */
#define GPIO_Sensor_PORT                                                 (GPIOA)

/* Defines for PIN_0: GPIOA.31 with pinCMx 6 on package pin 39 */
#define GPIO_Sensor_PIN_0_PIN                                   (DL_GPIO_PIN_31)
#define GPIO_Sensor_PIN_0_IOMUX                                   (IOMUX_PINCM6)
/* Defines for PIN_1: GPIOA.30 with pinCMx 5 on package pin 37 */
#define GPIO_Sensor_PIN_1_PIN                                   (DL_GPIO_PIN_30)
#define GPIO_Sensor_PIN_1_IOMUX                                   (IOMUX_PINCM5)
/* Defines for PIN_2: GPIOA.29 with pinCMx 4 on package pin 36 */
#define GPIO_Sensor_PIN_2_PIN                                   (DL_GPIO_PIN_29)
#define GPIO_Sensor_PIN_2_IOMUX                                   (IOMUX_PINCM4)
/* Defines for PIN_3: GPIOA.27 with pinCMx 60 on package pin 31 */
#define GPIO_Sensor_PIN_3_PIN                                   (DL_GPIO_PIN_27)
#define GPIO_Sensor_PIN_3_IOMUX                                  (IOMUX_PINCM60)

/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_MOTOR_init(void);
void SYSCFG_DL_PWM_Servo_init(void);
void SYSCFG_DL_UART_OPENMV_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
