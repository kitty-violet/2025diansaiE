################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Servo/Servo.c 

C_DEPS += \
./Servo/Servo.d 

OBJS += \
./Servo/Servo.o 

OBJS__QUOTED += \
"Servo\Servo.o" 

C_DEPS__QUOTED += \
"Servo\Servo.d" 

C_SRCS__QUOTED += \
"../Servo/Servo.c" 


